# Python Bokeh Chart

> Chart/visualization of the top horsepower cars. Created using Python and the Bokeh library. This is part of the data visualization YouTube tutorial

## Quick Start

```bash
# Install dependencies
pipenv install

# Generate html
python main.py
```
